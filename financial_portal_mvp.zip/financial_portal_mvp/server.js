const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const url = require('url');

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data.json');
const PUBLIC_DIR = path.join(__dirname, 'public');
const sessions = new Map();

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.pbkdf2Sync(password, salt, 120000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const candidate = crypto.pbkdf2Sync(password, salt, 120000, 64, 'sha512').toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(candidate));
}
function seed() {
  if (fs.existsSync(DATA_FILE)) return;
  const now = new Date().toISOString();
  const db = {
    users: [
      { id: 'u_admin', name: 'Administrador', email: 'admin@demo.com', role: 'admin', passwordHash: hashPassword('Admin123!'), active: true, createdAt: now },
      { id: 'u_client_1', name: 'Cliente Demo', email: 'cliente@demo.com', role: 'client', passwordHash: hashPassword('Cliente123!'), active: true, createdAt: now }
    ],
    accounts: [
      { id: 'acc_1', userId: 'u_client_1', currency: 'EUR', balance: 125000.00, pending: 0, status: 'active' }
    ],
    movements: [
      { id: crypto.randomUUID(), accountId: 'acc_1', type: 'deposit', description: 'Saldo inicial', amount: 125000, createdAt: now, createdBy: 'u_admin' }
    ],
    requests: [],
    audit: []
  };
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}
function readDb() { seed(); return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); }
function writeDb(db) { fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2)); }
function send(res, status, body, type = 'application/json') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
}
function getBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', chunk => { data += chunk; if (data.length > 1e6) req.destroy(); });
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); } catch { resolve({}); }
    });
  });
}
function parseCookies(req) {
  return Object.fromEntries((req.headers.cookie || '').split(';').filter(Boolean).map(c => {
    const [k, ...v] = c.trim().split('='); return [k, decodeURIComponent(v.join('='))];
  }));
}
function auth(req) {
  const token = parseCookies(req).session;
  if (!token || !sessions.has(token)) return null;
  const sess = sessions.get(token);
  const db = readDb();
  return db.users.find(u => u.id === sess.userId && u.active) || null;
}
function requireAuth(req, res) {
  const user = auth(req);
  if (!user) { send(res, 401, { error: 'No autenticado' }); return null; }
  return user;
}
function audit(db, actorId, action, meta) {
  db.audit.unshift({ id: crypto.randomUUID(), actorId, action, meta, createdAt: new Date().toISOString() });
}
function publicUser(u) { return { id: u.id, name: u.name, email: u.email, role: u.role, active: u.active }; }
function routeStatic(req, res) {
  let pathname = url.parse(req.url).pathname;
  if (pathname === '/') pathname = '/index.html';
  const filePath = path.join(PUBLIC_DIR, pathname);
  if (!filePath.startsWith(PUBLIC_DIR) || !fs.existsSync(filePath)) return false;
  const ext = path.extname(filePath).toLowerCase();
  const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8' };
  send(res, 200, fs.readFileSync(filePath), types[ext] || 'text/plain');
  return true;
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const method = req.method;
  if (!parsed.pathname.startsWith('/api/')) {
    if (!routeStatic(req, res)) send(res, 404, 'No encontrado', 'text/plain');
    return;
  }
  try {
    if (method === 'POST' && parsed.pathname === '/api/login') {
      const body = await getBody(req); const db = readDb();
      const user = db.users.find(u => u.email.toLowerCase() === String(body.email || '').toLowerCase() && u.active);
      if (!user || !verifyPassword(body.password || '', user.passwordHash)) return send(res, 401, { error: 'Credenciales incorrectas' });
      const token = crypto.randomBytes(32).toString('hex'); sessions.set(token, { userId: user.id, createdAt: Date.now() });
      res.setHeader('Set-Cookie', `session=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/`);
      return send(res, 200, { user: publicUser(user) });
    }
    if (method === 'POST' && parsed.pathname === '/api/logout') {
      const token = parseCookies(req).session; if (token) sessions.delete(token);
      res.setHeader('Set-Cookie', 'session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
      return send(res, 200, { ok: true });
    }
    const user = requireAuth(req, res); if (!user) return;
    const db = readDb();
    if (method === 'GET' && parsed.pathname === '/api/me') return send(res, 200, { user: publicUser(user) });
    if (method === 'GET' && parsed.pathname === '/api/dashboard') {
      if (user.role === 'admin') {
        return send(res, 200, { users: db.users.map(publicUser), accounts: db.accounts, requests: db.requests, movements: db.movements.slice(0, 100), audit: db.audit.slice(0, 100) });
      }
      const account = db.accounts.find(a => a.userId === user.id);
      return send(res, 200, { account, movements: db.movements.filter(m => m.accountId === account?.id), requests: db.requests.filter(r => r.userId === user.id) });
    }
    if (method === 'POST' && parsed.pathname === '/api/requests') {
      if (user.role !== 'client') return send(res, 403, { error: 'Solo clientes' });
      const body = await getBody(req); const amount = Number(body.amount);
      if (!amount || amount <= 0) return send(res, 400, { error: 'Importe inválido' });
      const account = db.accounts.find(a => a.userId === user.id); if (!account) return send(res, 400, { error: 'Cuenta no encontrada' });
      const request = { id: crypto.randomUUID(), userId: user.id, accountId: account.id, type: body.type || 'transfer', amount, currency: account.currency, destination: body.destination || '', note: body.note || '', status: 'pending', createdAt: new Date().toISOString(), reviewedAt: null, reviewedBy: null };
      db.requests.unshift(request); audit(db, user.id, 'CREATE_REQUEST', request); writeDb(db); return send(res, 201, { request });
    }
    if (method === 'POST' && parsed.pathname.startsWith('/api/admin/requests/')) {
      if (user.role !== 'admin') return send(res, 403, { error: 'Solo administrador' });
      const id = parsed.pathname.split('/')[4]; const body = await getBody(req);
      const request = db.requests.find(r => r.id === id); if (!request) return send(res, 404, { error: 'Solicitud no encontrada' });
      if (!['approved', 'rejected', 'executed'].includes(body.status)) return send(res, 400, { error: 'Estado inválido' });
      request.status = body.status; request.reviewedAt = new Date().toISOString(); request.reviewedBy = user.id;
      if (body.status === 'executed') {
        const account = db.accounts.find(a => a.id === request.accountId);
        if (account) {
          account.balance -= request.amount;
          db.movements.unshift({ id: crypto.randomUUID(), accountId: account.id, type: request.type, description: `Operación ejecutada: ${request.destination || request.note || request.type}`, amount: -request.amount, createdAt: new Date().toISOString(), createdBy: user.id });
        }
      }
      audit(db, user.id, 'UPDATE_REQUEST', { id, status: body.status }); writeDb(db); return send(res, 200, { request });
    }
    if (method === 'POST' && parsed.pathname === '/api/admin/users') {
      if (user.role !== 'admin') return send(res, 403, { error: 'Solo administrador' });
      const body = await getBody(req); const email = String(body.email || '').trim().toLowerCase();
      if (!email || !body.name || !body.password) return send(res, 400, { error: 'Faltan datos' });
      if (db.users.some(u => u.email.toLowerCase() === email)) return send(res, 409, { error: 'Email ya existe' });
      const newUser = { id: crypto.randomUUID(), name: body.name, email, role: 'client', passwordHash: hashPassword(body.password), active: true, createdAt: new Date().toISOString() };
      const account = { id: crypto.randomUUID(), userId: newUser.id, currency: 'EUR', balance: Number(body.balance || 0), pending: 0, status: 'active' };
      db.users.push(newUser); db.accounts.push(account); audit(db, user.id, 'CREATE_CLIENT', { userId: newUser.id, balance: account.balance }); writeDb(db);
      return send(res, 201, { user: publicUser(newUser), account });
    }
    send(res, 404, { error: 'Ruta no encontrada' });
  } catch (e) { send(res, 500, { error: 'Error interno', detail: e.message }); }
});
server.listen(PORT, () => console.log(`Portal financiero en http://localhost:${PORT}`));
