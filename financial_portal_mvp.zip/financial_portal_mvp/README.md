# Portal Financiero Privado - MVP

Aplicación web demo para clientes y administración.

## Funciones incluidas

- Login individual para cliente y administrador.
- Vista de saldo total del cliente.
- Historial de movimientos.
- Solicitud de transacciones como petición pendiente.
- Panel administrador/backoffice.
- Crear clientes con saldo inicial.
- Aprobar, rechazar o ejecutar solicitudes.
- Registro de auditoría en `data.json`.

## Cómo probar

1. Instalar Node.js 18 o superior.
2. Abrir terminal en esta carpeta.
3. Ejecutar:

```bash
npm start
```

4. Abrir en el navegador:

```text
http://localhost:3000
```

## Accesos demo

Administrador:

```text
admin@demo.com
Admin123!
```

Cliente:

```text
cliente@demo.com
Cliente123!
```

## Importante para producción

Este MVP no debe usarse en producción sin adaptar:

- Base de datos real: PostgreSQL/MySQL.
- HTTPS obligatorio.
- Doble factor de autenticación.
- Backups automáticos.
- KYC/AML si aplica.
- Auditoría reforzada e inmutable.
- Roles y permisos avanzados.
- Revisión legal/regulatoria si se gestionan fondos de terceros.

La app debe presentarse como portal privado de solicitudes, no como entidad bancaria ni sistema de pago regulado salvo autorización correspondiente.
